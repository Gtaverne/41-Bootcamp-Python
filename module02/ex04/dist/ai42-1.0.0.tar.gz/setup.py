from setuptools import setup, find_packages

setup(
	name="ai42",
	version='1.0.0',
	packages=['ai42'],
	install_requires=[]

)